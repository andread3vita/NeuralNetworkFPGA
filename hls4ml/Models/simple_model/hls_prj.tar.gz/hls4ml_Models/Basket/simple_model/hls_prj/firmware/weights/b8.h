//Numpy array shape [3]
//Min -0.038725886494
//Max 0.022521432489
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
output_bias_t b8[3];
#else
output_bias_t b8[3] = {0.0225214325, 0.0177094676, -0.0387258865};
#endif

#endif
