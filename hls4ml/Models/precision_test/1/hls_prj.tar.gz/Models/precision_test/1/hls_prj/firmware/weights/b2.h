//Numpy array shape [20]
//Min -0.250000000000
//Max 0.250000000000
//Number of zeros 8

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[20];
#else
bias2_t b2[20] = {0.25, 0.00, 0.00, 0.00, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.00, 0.00, 0.00, 0.25, -0.25, 0.00, 0.25, 0.00, 0.25, 0.25};
#endif

#endif
