//Numpy array shape [20]
//Min 0.000000000000
//Max 0.250000000000
//Number of zeros 12

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[20];
#else
bias5_t b5[20] = {0.00, 0.00, 0.25, 0.00, 0.25, 0.00, 0.00, 0.25, 0.00, 0.25, 0.25, 0.00, 0.00, 0.25, 0.00, 0.00, 0.25, 0.25, 0.00, 0.00};
#endif

#endif
