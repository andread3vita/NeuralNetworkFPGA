//Numpy array shape [3]
//Min -0.099121093750
//Max 0.151367187500
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
bias8_t b8[3];
#else
bias8_t b8[3] = {0.15136718750, 0.00537109375, -0.09912109375};
#endif

#endif
